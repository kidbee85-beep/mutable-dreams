/* SPDX-License-Identifier: MIT
 * USB-only bench protocol: F0 7D 4D 44 cmd seq payload F7.
 * Replies: same prefix, status, group-mask packed bytes. No flash writes.
 * cmd 1 telemetry; 2 up to 16 queued commands (c,t,value biased by 8192, two 7-bit bytes);
 * cmd 3 reset observed CPU peak; cmd 4 read patch chunk (offset in 2 x 7 bits).
 * cmd 6 snapshots the saved project (stopped only), returns size/magic/version;
 * optional one-byte object ID selects a named user Biome or tone bank for backup.
 * cmd 5 reads chunks of that immutable snapshot. This can preserve a foreign saved object.
 * cmd 22 reports the USB audio packets, buffer errors and minimum/maximum fill.
 * ACK for cmd 2 means queued, not applied: verify with subsequent snapshot.
 */
static uint8_t md_stored_snapshot[3840];
static uint32_t md_stored_size;
static uint8_t md_stored_generation;
#include "editor.c"
int app_sysex(const uint8_t *p,uint32_t n){
 if(n<3||p[0]!=0x7d||p[1]!=0x4d||p[2]!=0x44)return 0;
 if(n<5)return 1;
 uint8_t tx[280]={0xf0,0x7d,0x4d,0x44,p[3],p[4],0},raw[224];uint32_t len=0,at=7;
 if(p[3]==1&&n==5){
  uint32_t words[49]={0},f=plat_lock();const md_stats *s=md_status();const md_patch *v=md_state();
  words[0]=2;words[1]=plat_ms();words[2]=plat_cpu_pct();words[3]=cpu_peak;words[4]=plat_xruns();words[5]=overloads;
  words[6]=s->frames;words[7]=s->nonfinite;words[8]=s->dropped_commands;words[9]=md_quality_active(); /* F-3: what the render does now */words[10]=md_playing();
  for(int i=0;i<6;i++){words[11+i]=s->events[i];words[17+i]=v->track[i].model;words[23+i]=v->track[i].filter;}
  words[29]=md_memory_bytes();words[30]=v->version;words[31]=s->grain_writes;words[32]=v->freeze;
  memcpy(&words[33],&s->peak,4);words[34]=s->voice_quanta;words[35]=s->skipped_quanta;words[36]=md_tempo_now();words[37]=plat_audio_peak_us();words[38]=APP_BLOCK*1000000u/MD_RATE;words[39]=plat_master();words[40]=s->quality_reductions;
  words[41]=dream_prefs.motion;words[42]=dream_prefs.boot_sound;words[43]=dream_ui.page;words[44]=(uint32_t)dream_ui.help;words[45]=intro_active&&(uint32_t)(plat_ms()-intro_start)<3200;
  words[46]=s->element_modes;words[47]=ui_frames;words[48]=ui_frame_peak_ms;plat_unlock(f);len=sizeof words;memcpy(raw,words,len);
 }else if(p[3]==2&&n>=9&&n<=69&&(n-5)%4==0){
  uint32_t count=(n-5)/4,f=plat_lock();
  for(unsigned k=5;k<n;k+=4)if(!md_command_valid(p[k]))tx[6]=1;
  if(md_command_space()<count)tx[6]=2;
  for(unsigned k=5;k<n;k+=4)if(!md_command_allowed(p[k]))tx[6]=4;
  if(!tx[6])for(unsigned k=5;k<n;k+=4){int c=p[k],t=p[k+1],v=(int)(p[k+2]|p[k+3]<<7)-8192;
   if(c==MD_MIDI_ROUTE)v=clamp(v,0,16);
   if(c==MD_MIDI_MACRO)v=clamp(v,0,1);
   md_command(c,t,v);
   if(c==MD_MIDI_ROUTE&&t>=0&&t<6)dream_prefs.midi_route[t]=v;
   if(c==MD_MIDI_MACRO)dream_prefs.midi_macro=v;
  }
  plat_unlock(f);
 }
 else if(p[3]==3&&n==5){uint32_t f=plat_lock();cpu_peak=ui_frame_peak_ms=0;plat_audio_peak_reset();
#ifdef MD_PROFILE
  md_prof_reset();
#endif
  plat_unlock(f);}
#ifdef MD_PROFILE
 else if(p[3]==23&&n==6&&p[5]<2){uint32_t w[56]={0},f=plat_lock();len=(uint32_t)md_prof_read(w,p[5])*4;plat_unlock(f);memcpy(raw,w,len);}
 else if(p[3]==24&&(n==5||n==7)){uint32_t w[56]={0},f=plat_lock();len=(uint32_t)md_prof_avg(w,n==7?(unsigned)(p[5]|p[6]<<7):0u,n==7)*4;plat_unlock(f);memcpy(raw,w,len);}
#endif
#ifdef MD_MIX_DEVICE
 else if(p[3]==26&&n==5){
  extern char _ustack_lo[],_ustack_top[],_sstack_lo[],_sstack_top[];
  uint32_t w[12]={0x4d584332u,1,4,(uint32_t)plat_stack_left(PLAT_STK_MAIN),(uint32_t)plat_stack_left(PLAT_STK_IRQ),(uint32_t)plat_stack_left(PLAT_STK_C1),APP_BLOCK,MD_RATE,(uint32_t)((uintptr_t)_ustack_top-(uintptr_t)_ustack_lo),(uint32_t)((uintptr_t)_sstack_top-(uintptr_t)_sstack_lo),2816,256};
  memcpy(raw,w,sizeof w);len=sizeof w;
 }
 else if(p[3]==27&&(n==5||n==7)){
  uint32_t f=plat_lock();
  if(n==7){if(md_playing())tx[6]=4;
   else if(p[5]==1&&(p[6]==1||p[6]==16||p[6]==32||p[6]==64||p[6]==65))md_mix_min_frames=p[6];
#ifdef MD_CPU2_FAULT_TEST
   else if(p[5]==2&&p[6]<=2&&plat_cpu2_on())mix2_inject=p[6];
#endif
   else tx[6]=1;}
  uint32_t w[24];len=mix2_read(w);plat_unlock(f);memcpy(raw,w,len);
 }
#endif
 else if(p[3]==19&&n==5){
  uint32_t levels=0,pulses=0,grains=0;
  for(unsigned i=0;i<6;i++){if(living.level[i])levels|=1u<<i;if(living.age[i]<160)pulses|=1u<<i;}
  for(unsigned i=0;i<4;i++)if(living.window[i])grains|=1u<<i;
  uint32_t w[]={display_tiles_sent,display_tiles_skipped,living.profile,levels,pulses,grains,
                (uint32_t)timeline.section,timeline.step,(uint32_t)timeline.next,timeline.keep};
  memcpy(raw,w,sizeof w);len=sizeof w;
 }
 else if(p[3]==20&&n==5){
  int32_t w[12];uint32_t lock=plat_lock();
  w[6]=0;
  for(unsigned i=0;i<MD_TRACKS;i++){
   int hit;
   w[i]=md_sequence_playhead(i,&hit);
   w[6]|=hit<<i;
  }
  w[7]=md_sequence_clipboard();w[8]=md_sequence_notice();
  plat_unlock(lock);
  w[9]=seq_scope;w[10]=seq_interval;w[11]=seq_action;
  memcpy(raw,w,sizeof w);len=sizeof w;
 }
 else if(p[3]==21&&n==5){
  /* Phrase Tools (bit 0), exact replay (bit 1), polarity (bit 2), clear slot (bit 3), grain LFO targets (bit 4). */
  const uint32_t features=31u;
  memcpy(raw,&features,sizeof features);len=sizeof features;
 }
#if defined(FELUCCA_UAC) && FELUCCA_UAC
 else if(p[3]==22&&n==5){
  uint32_t lock=plat_lock();
  uint32_t w[]={uac.pkts,uac.underruns,uac.overruns,uac.missed,uac.stalls,uac.fill_lo,uac.fill_hi};
  plat_unlock(lock);
  memcpy(raw,w,sizeof w);len=sizeof w;
 }
#endif
 else if(p[3]==4&&n==7){unsigned off=p[5]|p[6]<<7;if(off>=sizeof(md_patch))tx[6]=1;else{len=sizeof(md_patch)-off;if(len>224)len=224;uint32_t f=plat_lock();memcpy(raw,((const uint8_t*)md_state())+off,len);plat_unlock(f);}}
 else if(p[3]==6&&(n==5||n==6)){
  md_stored_size=0;md_stored_generation=(md_stored_generation+1)&127;
  unsigned obj=n==6?p[5]:OBJ_PATCH;
  /* Bluetooth bond keys (OBJ_BLE) never leave the FM-1 over SysEx. */
  if(obj!=OBJ_PATCH&&(obj<OBJ_USER||obj>=OBJ_BLE))tx[6]=1;
  else if(md_playing()||md_clock_source())tx[6]=4;else{int size=plat_store_size(obj);if(size<12||size>(int)sizeof md_stored_snapshot)tx[6]=3;
   else if(plat_store_load(obj,md_stored_snapshot,(uint32_t)size)!=size)tx[6]=3;
   else{md_stored_size=(uint32_t)size;memcpy(raw,&md_stored_size,4);memcpy(raw+4,md_stored_snapshot,8);len=12;}}
 }
 else if(p[3]==5&&(n==7||n==8)){unsigned off=p[5]|p[6]<<7;if((n==8&&p[7]!=md_stored_generation)||off>=md_stored_size)tx[6]=3;else{len=md_stored_size-off;if(len>224)len=224;memcpy(raw,md_stored_snapshot+off,len);}}
 else if(p[3]==16&&n>=10&&n<=85&&(n-5)%5==0){
  unsigned count=(n-5)/5;uint32_t f=plat_lock();
  for(unsigned k=5;k<n;k+=5){int c=p[k]|p[k+1]<<7;if(!md_command_valid(c)||c<128)tx[6]=1;else if(!md_command_allowed(c))tx[6]=4;}
  if(md_command_space()<count)tx[6]=2;
  if(!tx[6])for(unsigned k=5;k<n;k+=5)md_command(p[k]|p[k+1]<<7,p[k+2],(int)(p[k+3]|p[k+4]<<7)-8192);
  plat_unlock(f);
 }
 else if((p[3]>=7&&p[3]<=15)||p[3]==17||p[3]==18)tx[6]=editor_reply(p,n,raw,&len);
 else tx[6]=1;
 for(unsigned i=0;i<len;){unsigned k=len-i;if(k>7)k=7;uint8_t mask=0;for(unsigned j=0;j<k;j++)mask|=(raw[i+j]>>7)<<j;tx[at++]=mask;for(unsigned j=0;j<k;j++)tx[at++]=raw[i+j]&127;i+=k;}
 tx[at++]=0xf7;plat_sysex_send(tx,at);return 1;
}
