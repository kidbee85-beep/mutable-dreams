MUTABLE DREAMS 2.4 / USB INSTALLER
Kid Bunka · application build 8FBE5AF8 · FM-1_710020400

Python 3.11+. Install: python3 -m pip install -r requirements.txt
Back up saved User Banks, the edited live Biome, Favorites and Tone stars first.
Read the 2.4 manual and Recovery-2.4.html before changing firmware.

Inspect the single intended FM-1: python3 fm1_install.py --info
Install the supplied application: python3 fm1_install.py Mutable-Dreams-2.4.fwsc --yes
Keep USB connected until restart and identity verification finish. Do not use --force.
This does not install a bootloader. Official stock firmware is not bundled.

Package SHA-256: 0923a0e1bb05f8b0fc6111e4274be38436e37a2a66790a58d12bf60bb7a2e004
